#pragma once

#define HTTP_SERVER "34.226.143.97"
#define HTTP_PORT 80

#define TFTP_SERVER "34.226.143.97"
